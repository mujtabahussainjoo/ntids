<?php

namespace Serole\Racvportal\Controller\Cart;

use Magento\Framework\View\Result\PageFactory;

class Createorder extends \Serole\Racvportal\Controller\Cart\Ajax {

    public function execute(){
        //echo $this->customerSession->getConfirmOrder(); exit;
        //echo $this->coreSession->getConfirmOrder(); exit;
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/Racvportal-ajaxcart-createorder.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);

        $data = array();
        $items = array();
        $sageError = 0;
        try{
            //if ($this->getRequest()->isAjax()) {
                //if ($this->getRequest()->getParams()) {
                    $customerSession = $this->customerSession;
                    if ($customerSession->isLoggedIn()) {
                        $parms = $this->getRequest()->getParams();
                        $shopData = $this->helper->getShopData();
                        if ($shopData) {
                            
                            $address = ['firstname' => $shopData['name'],
                                        'lastname' => $shopData['name'],
                                        'street' => $shopData['street'],
                                        'city' => $shopData['suburb'],
                                        'country_id' => 'AU',
                                        'region' => $shopData['region'],
                                        'postcode' => $shopData['postcode'],
                                        'telephone' => $shopData['phone'],
                                        'fax' => '',
                                    ];

                            $this->_quoteId = $this->cart->getQuote()->getId();
                            $cartItems = $this->cart->getQuote()->getAllItems();

                            $i=0;
                            foreach ($cartItems as $key => $cartItem) {
                                $items[$key]['identifier'] = $cartItem->getSku();
                                $items[$key]['type'] = "sku";
                                $items[$key]['qty'] = $cartItem->getQty();

                                $prod = $this->sageHelper->getProductBySku($cartItem->getSku());
                                $typeId = $prod->getTypeId();
                                if($typeId == "bundle"){
                                    $this->getBundleProductOptionsData($prod, $cartItem->getQty(), $i);
                                }else{
                                    $isStockItem = $prod->getIsStockItem();
                                    if(isset($isStockItem) && $isStockItem == 1){
                                        $itemSku = $cartItem->getSku();
                                        $itemQty = $cartItem->getQty();
                                        $quoteId = $this->_quoteId;
                                        $this->_stockUpdateArray[] = "$quoteId,$itemSku,$itemQty,1";
                                        $this->_sku[] = $prod->getSku();
                                        $this->_skuQty[$i][trim($prod->getSku())]['qty'] = $cartItem->getQty();
                                        $this->_skuQty[$i][trim($prod->getSku())]['type'] = "not-bundle";
                                        $this->_skuQty[$i][trim($prod->getSku())]['bundle-sku'] = "NA";
                                    }
                                }
                               $i++;
                            }

                            $sageResponse = $this->sageInventory->getSageStockCheck($items);

                            if($sageResponse['error'] == 1){
                                $data['outofstock'] = 1;
                                $data['status'] = 'error';
                                $data['message'] = $sageResponse['errorString'];
                                $data['customersession'] = 'yes';
                                echo json_encode($data);
                            }else {
                                $this->cart->getQuote()->getBillingAddress()->addData($address);
                                $this->cart->getQuote()->getShippingAddress()->addData($address);
                                $shippingAddress = $this->cart->getQuote()->getShippingAddress();
                                $shippingAddress->setCollectShippingRates(true)
                                                ->collectShippingRates()
                                                ->setShippingMethod('freeshipping_freeshipping'); //shipping method

                                $this->cart->getQuote()->setPaymentMethod('portalpayment'); //payment method
                                $this->cart->getQuote()->setInventoryProcessed(false); //not effetc inventory

                                $this->cart->save(); //Now Save quote and your quote is ready

                                $this->cart->getQuote()->getPayment()->importData(['method' => 'portalpayment']);
                                $this->cart->getQuote()->collectTotals()->save();

                                $order = $this->quoteManagement->submit($this->cart->getQuote());
                                $incrementId = $order->getRealOrderId();
                                if ($incrementId) {
                                         $this->customerSession->setConfirmOrder($incrementId);
                                         $this->coreSession->setOrderconfirmStatus($incrementId);
                                    if(!empty($this->_sku)){
                                        $logger->info($this->_sku);
                                        $logger->info($this->_skuQty);
                                        $result = $this->sageInventory->getCheckStock($this->_sku, $this->_skuQty);
                                        $logger->info($result);
                                        $logger->info('skus:'.$result["errorSkus"]);

                                        if($result['error'] == 1){
                                            $message = $result["errorString"];
                                            $this->_messageManager->addError($message);
                                            $this->sageHelper->setValue($result["errorSkus"]);
                                            $sageError = 1;
                                        }else{
                                            if(!empty($this->_stockUpdateArray)){
                                                $logger->info("Stock Update Api Request");
                                                $logger->info($this->_stockUpdateArray);
                                                $updateResult = $this->sageInventory->stockUpdate($this->_stockUpdateArray);
                                                $logger->info("Stock Update Api Response");
                                                $logger->info($updateResult);
                                                if($updateResult['error'] == 1){
                                                    $message = $updateResult["errorString"];
                                                    mail("dhananjay.kumar@serole.com", "Error in Stockupdate API", $message);
                                                }
                                            }
                                        }
                                    }

                                    $resultPage = $this->resultPageFactory->create();
                                    $block = $resultPage->getLayout()
                                        ->createBlock('Serole\Racvportal\Block\Ajaxcart')
                                        ->setTemplate('Serole_Racvportal::ajaxcart.phtml');
                                    $htmlResponse = $block->toHtml();
                                    $data['html'] = $htmlResponse;
                                    $data['status'] = 'sucess';
                                    $data['orderid'] = $incrementId;
                                    $data['customersession'] = 'yes';
                                    if($sageError = 1){
                                        $data['sageerror'] = 'yes';
                                    }
                                    echo json_encode($data);
                                }
                            }
                        } else {
                            $data['status'] = 'error';
                            $data['message'] = "You don't have Billing Address, Please contact us";
                            $data['customersession'] = 'yes';
                            echo json_encode($data);
                        }

                    } else {
                        #customer not log-in action
                        $resultPage = $this->resultPageFactory->create();
                        $block = $resultPage->getLayout()
                            ->createBlock('Serole\Racvportal\Block\Ajaxcart')
                            ->setTemplate('Serole_Racvportal::customersession.phtml');
                        //$htmlResponse = $this->getResponse()->setBody($block->toHtml());
                        $htmlResponse = $block->toHtml();
                        $data['html'] = $htmlResponse;
                        $data['status'] = 'sucess';
                        $data['customersession'] = 'no';
                        echo json_encode($data);
                    }
                //}
           // }
        }catch(\Exception $e){
            $logger->info($e->getMessage());
            $data['status'] = 'error';
            $data['message'] = $e->getMessage();
            $data['customersession'] = 'yes';
            echo json_encode($data);
        }
    }

    public function getBundleProductOptionsData($product, $qty, $i){
        //get all the selection products used in bundle product.
        //$product = $this->_productFactory->create()->load($productId);

        $selectionCollection = $product->getTypeInstance(true)
            ->getSelectionsCollection(
                $product->getTypeInstance(true)->getOptionsIds($product),
                $product
            );
        $quoteId = $this->_quoteId;
        foreach ($selectionCollection as $proselection) {
            $chldProd = $this->sageHelper->getProductBySku($proselection->getSku());
            $isStockItm = $chldProd->getIsStockItem();
            if(isset($isStockItm) && $isStockItm == 1) {
                $itemSku = $proselection->getSku();
                $itemQty = $qty*$proselection->getSelectionQty();
                $this->_stockUpdateArray[] = "$quoteId,$itemSku,$itemQty,1";
                $this->_sku[] = $proselection->getSku();
                $this->_skuQty[$i][trim($proselection->getSku())]['qty'] = $qty*$proselection->getSelectionQty();
                $this->_skuQty[$i][trim($proselection->getSku())]['type'] = "bundle";
                $this->_skuQty[$i][trim($proselection->getSku())]['bundle-sku'] = $product->getSku();
            }
        }

    }

}

/*
      Array(
          [entity_id] => 2
          [name] => Bendigo RACV Shop
          [street] => 112 Mitchell Street
          [suburb] => Bendigo
          [region] => 0
          [postcode] => 3550
          [phone] => 03 5443 9622
          [status] => 1
          [updated_at] => 2017-10-01 23:17:49
          [created_at] => 2017-10-01 23:17:45
          [store_id] => 0
       )*/