<?php

namespace Serole\Racvportal\Controller\Cart;

use Magento\Framework\View\Result\PageFactory;

class Pastorders extends \Serole\Racvportal\Controller\Cart\Ajax {

    public function execute(){
         try {
            $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/Racvportal-pastordres.log');
            $logger = new \Zend\Log\Logger();
            $logger->addWriter($writer);

            $date = date('Y-m-d');
            $filterDate = date('Y-m-d', strtotime($date . '-2 weeks'));
            $parms = $this->getRequest()->getParams();
            $storeId = $this->store->getStore()->getId();
            $orderColl = $this->order->getCollection();
            $orderColl->addFieldToFilter('store_id', $storeId);
            $orderColl->addFieldToFilter('created_at', ['gteq' => $filterDate]);
            if ($parms['customer'] == 'yes') {
                $orderColl->addFieldToFilter('customer_id', $this->helper->getCustomerId());
            }

            $orderColl->getSelect()->joinLeft(
                ['ot' => 'racvportal'],
                "main_table.increment_id = ot.increment_id"
            );
            $shopId = $this->helper->getShopId();
            if ($parms['shop'] == 'yes') {
                $orderColl->getSelect()->where('ot.shop_id=' . $shopId);
            }
            $orderColl->getSelect()->order('main_table.increment_id DESC');
            if ($parms['order'] == 'no') {
                $orderColl->getSelect()->limit(1);
            }
            $sql = $orderColl->getSelect();
            $logger->info($sql);
            $connection = $this->resourceConnection->getConnection();
            $resultData = $connection->fetchAll($sql);
            $resultData = $orderColl->getData();

            $resultPage = $this->resultPageFactory->create();
            $block = $resultPage->getLayout()
                                ->createBlock('Serole\Racvportal\Block\Onepage')
                                ->setTemplate('Serole_Racvportal::pastorders.phtml')
                               ->setData('data', $resultData);
            $htmlResponse = $block->toHtml();
            $data['html'] = $htmlResponse;
            $data['status'] = 'sucess';
            $data['customersession'] = 'yes';
            ob_start();
            echo json_encode($data);
        }catch (\Exception $e){
            $logger->info($e->getMessage());
            $data['status'] = 'error';
            $data['customersession'] = 'yes';
            $data['message'] = $e->getMessage();
            echo json_encode($data);
        }
    }
}