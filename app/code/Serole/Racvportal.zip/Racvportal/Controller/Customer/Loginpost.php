<?php

namespace Serole\Racvportal\Controller\Customer;

use Magento\Customer\Api\AccountManagementInterface;
use Magento\Customer\Model\Account\Redirect as AccountRedirect;
use Magento\Customer\Model\Session;
use Magento\Customer\Model\Url as CustomerUrl;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\View\Result\PageFactory;


    class Loginpost extends \Magento\Customer\Controller\Account\LoginPost {

        protected $customer;

        protected $storeManager;

        public function __construct(Context $context,
                                    Session $customerSession,
                                    AccountManagementInterface $customerAccountManagement,
                                    CustomerUrl $customerHelperData,
                                    Validator $formKeyValidator,
                                    AccountRedirect $accountRedirect,
                                    \Magento\Store\Model\StoreManagerInterface $storeManager,
                                    \Magento\Customer\Model\Customer $customer)
        {
            parent::__construct($context, $customerSession, $customerAccountManagement, $customerHelperData, $formKeyValidator, $accountRedirect);
            $this->customer = $customer;
            $this->storeManager = $storeManager;
        }

        public function execute(){
            if ($this->session->isLoggedIn() || !$this->formKeyValidator->validate($this->getRequest())) {
                $resultRedirect = $this->resultRedirectFactory->create();
                $resultRedirect->setPath('*/*/');
                return $resultRedirect;
            }
            //echo "<pre>"; print_r($this->getRequest()->getParams());
            if ($this->getRequest()->isPost()) {
                $login = $this->getRequest()->getPost('login');
                if (!empty($login['username']) && !empty($login['password']) && !empty($login['shop'])) {
                    try {
                        $customerObj = $this->customer->getCollection();
                        $customerObj->addAttributeToSelect('*')
                                    ->addAttributeToFilter('memberno',$login['username'])
                                    ->load();
                        $customer = $customerObj->getFirstItem();
                        $customerData = $customer->getData();
                        if(!empty($customerData)){
                            $customerEmail = $customerData['email'];
                            $customer = $this->customerAccountManagement->authenticate($customerEmail, $login['password']);
                            $this->session->setCustomerDataAsLoggedIn($customer);
                            $this->session->regenerateId();
                            $storeData = $this->storeManager->getStore();
                            $storeUrl = $storeData->getUrl();
                            $this->session->setRacvShop($login['shop']);
                            $this->session->setMemberNo($login['username']);
                            $this->accountRedirect->clearRedirectCookie();
                            $resultRedirect = $this->resultRedirectFactory->create();
                            // URL is checked to be internal in $this->_redirect->success()
                            $resultRedirect->setUrl($this->_redirect->success($storeUrl));
                            return $resultRedirect;

                        }else{
                            $this->messageManager->addError(
                                __('This customer not exist, please cotact us')
                            );
                        }
                    } catch (EmailNotConfirmedException $e) {
                        $value = $this->customerUrl->getEmailConfirmationUrl($login['username']);
                        $message = __(
                            'This account is not confirmed. <a href="%1">Click here</a> to resend confirmation email.',
                            $value
                        );
                        $this->messageManager->addError($message);
                        $this->session->setUsername($login['username']);
                    } catch (UserLockedException $e) {
                        $message = __(
                            'You did not sign in correctly or your account is temporarily disabled.'
                        );
                        $this->messageManager->addError($message);
                        $this->session->setUsername($login['username']);
                    } catch (AuthenticationException $e) {
                        $message = __('You did not sign in correctly or your account is temporarily disabled.');
                        $this->messageManager->addError($message);
                        $this->session->setUsername($login['username']);
                    } catch (LocalizedException $e) {
                        $message = $e->getMessage();
                        $this->messageManager->addError($message);
                        $this->session->setUsername($login['username']);
                    } catch (\Exception $e) {
                        // PA DSS violation: throwing or logging an exception here can disclose customer password
                        $this->messageManager->addError(
                            __('An unspecified error occurred. Please contact us for assistance.')
                        );
                    }
                } else {
                    $this->messageManager->addError(__('A login and a password are required.'));
                }
            }

            return $this->accountRedirect->getRedirect();
        }
    }
