var config = {
    map: {
        '*': {
            popupjs: 'Serole_Racvportal/js/bootstrap-notify'
        }
    }
};