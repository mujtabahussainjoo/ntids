<?php
namespace Serole\Sage\Controller\Product;

class Test extends \Magento\Framework\App\Action\Action
{

    protected $resultPageFactory;
	
	protected $_inventory;
	

    /**
     * Constructor
     *
     * @param \Magento\Framework\App\Action\Context  $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
		\Serole\Sage\Model\Inventory $Inventory,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        $this->resultPageFactory = $resultPageFactory;
		$this->_inventory = $Inventory;
        parent::__construct($context);
    }

    /**
     * Execute view action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
		$data = array("q1,o1,ACE-MOV-NP-ADU1111,S00001","q1,o1,ACE-MOV-NP-ADU-001,S00002");
		$this->_inventory->CheckPhysicalSerialCode($data);
        //return $this->resultPageFactory->create();
    }
}
?>