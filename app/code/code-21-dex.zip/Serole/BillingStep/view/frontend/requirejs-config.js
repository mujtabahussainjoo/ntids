var config = {
    map: {
        '*': {
            "Magento_Checkout/js/view/payment": "Serole_BillingStep/js/view/payment",
            'Magento_Checkout/js/model/shipping-save-processor/default': 'Serole_BillingStep/js/model/shipping-save-processor/default'
        }
    }
};