<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Serole\Accountpayment\Model;



/**
 * Pay In Store payment method model
 */
class Accountpayment extends \Magento\Payment\Model\Method\AbstractMethod
{

    /**
     * Payment code
     *
     * @var string
     */
    protected $_code = 'accountpayment';

    /**
     * Availability option
     *
     * @var bool
     */
    protected $_isOffline = true;



    public function isAvailable(\Magento\Quote\Api\Data\CartInterface $quote = null) {

    }

    public function capture(\Magento\Payment\Model\InfoInterface $payment, $amount)
    {
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/account-payment-capture.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);

        $paymentInfo = $this->getInfoInstance();
        $orderId = $paymentInfo->getOrder()->getRealOrderId();

        $logger->info("Order-Id".$orderId);

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $order = $objectManager->create('\Magento\Sales\Model\Order')->loadByIncrementId($orderId);

        if(!$order->canInvoice()){
            $logger->info("Can not Invoices".$orderId);
            throw new \Magento\Framework\Exception\LocalizedException(__('The capture action is not available.'));
        }

        $invoice = $objectManager->create('Magento\Sales\Model\Service\InvoiceService')->prepareInvoice($order);

        if (!$invoice->getTotalQty()) {
            $logger->info("No Total Qty for".$orderId);
            throw new \Magento\Framework\Exception\LocalizedException(
                __('You can\'t create an invoice without products.')
            );
        }

        $invoice->setRequestedCaptureCase(\Magento\Sales\Model\Order\Invoice::CAPTURE_OFFLINE);
        $invoice->register();

        /*$invoice->getOrder()->setCustomerNoteNotify(true);
        $invoice->getOrder()->setIsInProcess(true);*/

        try {
            $invoiceCreate = $objectManager->create('Magento\Framework\DB\Transaction')
                ->addObject($invoice)
                ->addObject($invoice->getOrder());

            $invoiceCreate->save();
            $this->invoiceSender->send($invoice);
            
            $order->setCustomerNoteNotify(true);
            $order->setIsInProcess(true);
            $order->save();

        }catch (\Exception $e){
            $logger->info("Expection for".$orderId."---".$e->getMessage());
        }

        $logger->info("Order Status of".$orderId."---".$order->getStatus());

        return true;
    }

  

}
