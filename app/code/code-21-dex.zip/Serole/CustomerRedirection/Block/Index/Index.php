<?php

namespace Serole\CustomerRedirection\Block\Index;

use Serole\CustomerRedirection\Block\BaseBlock;

class Index extends BaseBlock
{
	public $hello='Hello World';
	
}
