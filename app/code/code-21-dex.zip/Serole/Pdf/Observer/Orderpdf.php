<?php

namespace Serole\Pdf\Observer;

use Magento\Framework\Event\ObserverInterface;


class Orderpdf implements ObserverInterface {

    public $createPdf;

    public function __construct(\Serole\Pdf\Model\Createpdf $createPdf

    ) {
        $this->createPdf = $createPdf;
    }

    public function execute(\Magento\Framework\Event\Observer $observer) {

        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/order-pdfconcept-process.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);

        //$order = $observer->getEvent()->getOrder();
        $invoice = $observer->getEvent()->getInvoice();
        $order = $invoice->getOrder();
        /*Getting data from order*/
        //$orderId = $order->getId();
        $orderId = $order->getIncrementId();
        //$logger->info("Order Id is".$orderId);
        if($orderId) {
            try {
                $pdf = $this->createPdf->createPdfConcept($orderId, $email = TRUE,'frontend');
            } catch (\Exception $e) {
                $logger->info($e->getMessage());
            }
        }else{
            $logger->info("Order Id is emprty");
        }
    }

}

