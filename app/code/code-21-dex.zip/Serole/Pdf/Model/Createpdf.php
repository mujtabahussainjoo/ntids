<?php

namespace Serole\Pdf\Model;

use Magento\Framework\Event\ObserverInterface;

use Zend_Barcode;

require '/var/www/html/lib/gearpdf/vendor/autoload.php';

class Createpdf extends \Magento\Framework\Model\AbstractModel {

    protected $product;

    protected $orderPdf;

    protected $order;

    protected $orderItemsCollection;

    protected $orderItemSerialcode;

    protected $pdfHelper;

    protected $date;

    protected $productOptions;

    protected $giftMessage;

    protected $giftImage;

    protected $fileSystemPath;

    protected $barCodesDirectoryPath;

    protected $temporaryDocFilesPath;

    protected $temporaryPdfFilesPath;

    protected $mergedPdfFilesPath;

    protected $barcodeFilesPath;

    protected $mediaPath;

    protected $logoUrl;

    protected $virtualProductfilesListArray;

    protected $bundleProductfilesListArray;

    protected $totalOrderQty;

    protected $orderSerialCodesQtyFromTable;

    protected $useSerialCodesFromTable;

    protected $useSageSerialCodes;

    protected $serialCodesQtyIssueFromTable;

    protected $isProductMissedJsonData;

    protected $isProductSerialised;

    protected $errorList;

    protected $isPdfGroupTicket;

    protected $productattachment;

    protected $productDocsFilePath;

    public function __construct(\Magento\Catalog\Model\Product $product,
                                \Serole\Pdf\Model\Pdf $orderPdf,
                                \Serole\Serialcode\Model\OrderitemSerialcode $orderItemSerialcode,
                                \Magento\Sales\Model\Order\Item $orderItemsCollection,
                                \Magento\Sales\Model\Order $order,
                                \Serole\Pdf\Helper\Pdf $pdfHelper,
                                \Serole\Productattachment\Model\Productattachment $productattachment,
                                \Magento\Framework\Stdlib\DateTime\DateTime $date,
                                \Magento\Catalog\Model\Product\Option $productOptions,
                                \Serole\GiftMessage\Model\Message $giftMessage,
                                \Serole\GiftMessage\Model\Image $giftImage,
                                \Magento\Customer\Model\Session $customerSession,
                                \Magento\Checkout\Model\Session $checkoutSession

    ) {
        $this->customerSession =$customerSession;
        $this->productattachment = $productattachment;
        $this->product = $product;
        $this->orderItems = $orderItemsCollection;
        $this->orderPdf = $orderPdf;
        $this->order = $order;
        $this->orderItemSerialcode = $orderItemSerialcode;        
        $this->pdfHelper = $pdfHelper;
        $this->date = $date;
        $this->productOptions = $productOptions;
        $this->giftMessage = $giftMessage;
        $this->giftImage = $giftImage;
        $this->fileSystemPath = '';
        $this->directoryPath = '';
        $this->temporaryDocFilesPath = '';
        $this->temporaryPdfFilesPath = '';
        $this->mergedPdfFilesPath = '';
        $this->barcodeFilesPath = '';
        $this->mediaPath = '';
        $this->logoUrl = '';
        $this->virtualProductfilesListArray = array();
        $this->bundleProductfilesListArray = array();
        $this->itemData = array();
        $this->virtualProductfilesListArray['doc'] = array();
        $this->virtualProductfilesListArray['pdf'] = array();
        $this->bundleProductfilesListArray['doc'] =  array();
        $this->bundleProductfilesListArray['pdf'] =  array();
        $this->orderId = '';
        $this->checkoutSession = $checkoutSession;
        $this->totalOrderQty = 0;
        $this->orderSerialCodesQtyFromTable = 0;
        $this->useSerialCodesFromTable = 0;
        $this->useSageSerialCodes = 1;
        $this->serialCodesQtyIssueFromTable = 0;
        $this->isProductMissedJsonData = array();
        $this->isProductSerialised = array();
        $this->errorList = array();
        $this->isPdfGroupTicket = array();
        $this->productDocsFilePath = array();
    }


    public function createPdfConcept($orderId,$emailStauts,$reqType){

        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/pdf-create-createPdfConcept.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);

        $order = $this->order->loadByIncrementId($orderId);

        if($order->hasInvoices()) {
            $quoteId = $order->getQuoteId();
            $this->orderId = $orderId;//$order->getId();
            $incrementId = $order->getIncrementId();
            $this->incrementId = $order->getIncrementId();
            $customerId = $order->getCustomerId();
            $isGuest = $order->getCustomerIsGuest();

            $totalQtyOrdered = $order->getTotalQtyOrdered();

            $giftMessageObj = $this->giftMessage->getCollection();
            $giftMessageObj->addFieldToFilter('order_id', $incrementId);
            $giftMessageData = $giftMessageObj->getFirstItem()->getData();

            $customerData = array();

            if ($giftMessageData) {
                $emailTemplateObj = $this->giftImage->load($giftMessageData['image']);
                $emailTemplateData = $emailTemplateObj->getData();
                $customerData['name'] = $giftMessageData['to'];
                $customerEmail = $giftMessageData['email'];
                $customerData['message'] = $giftMessageData['message'];
                $customerData['from'] = $giftMessageData['from'];
                if ($emailTemplateData) {
                    $customerData['emailtemplateid'] = $emailTemplateData['emailtemplateid'];
                }
            } else {
                $customerFirstName = $order->getCustomerFirstname();
                $customerLastName = $order->getCustomerLastname();
                $deliveryemail = $order->getdeliveryemail();
                if ($deliveryemail) {
                    $customerEmail = $deliveryemail;
                } else {
                    $customerEmail = $order->getCustomerEmail();
                }
                $customerData['name'] = $customerFirstName . ' ' . $customerLastName;
            }
            $customerData['email'] = $customerEmail;
            
            $orderItems = $order->getAllItems();

            $this->directoryPath = $this->pdfHelper->getMediaBaseDir();
            $this->mediaPath = $this->pdfHelper->getMediaBaseDir();
            $logoPath = $this->pdfHelper->getLogo('design/header/logo_src');
            $this->logoUrl = $this->mediaPath . 'logo/' . $logoPath;

            $this->fileSystemPath = $this->pdfHelper->getRootBaseDir();
            $this->temporaryDocFilesPath = $this->fileSystemPath . 'neatideafiles/temporryfiles/doc/';
            $this->temporaryPdfFilesPath = $this->fileSystemPath . 'neatideafiles/temporryfiles/pdf/';
            $this->mergedPdfFilesPath = $this->fileSystemPath . 'neatideafiles/pdf/';
            $this->barcodeFilesPath = $this->fileSystemPath . 'neatideafiles/barcodeimages/';


            if (!file_exists($this->temporaryDocFilesPath)) {
                mkdir($this->temporaryDocFilesPath, 0777, true);
                chmod($this->temporaryDocFilesPath, 0777);
            }
            if (!is_writable($this->temporaryDocFilesPath)) {
                chmod($this->temporaryDocFilesPath, 0777);
            }


            if (!file_exists($this->temporaryPdfFilesPath)) {
                mkdir($this->temporaryPdfFilesPath, 0777, true);
                chmod($this->temporaryPdfFilesPath, 0777);
            }
            if (!is_writable($this->temporaryPdfFilesPath)) {
                chmod($this->temporaryPdfFilesPath, 0777);
            }


            if (!file_exists($this->mergedPdfFilesPath)) {
                mkdir($this->mergedPdfFilesPath, 0777, true);
                chmod($this->mergedPdfFilesPath, 0777);
            }
            if (!is_writable($this->mergedPdfFilesPath)) {
                chmod($this->mergedPdfFilesPath, 0777);
            }


            if (!file_exists($this->barcodeFilesPath)) {
                mkdir($this->barcodeFilesPath, 0777, true);
                chmod($this->barcodeFilesPath, 0777);
            }
            if (!is_writable($this->barcodeFilesPath)) {
                chmod($this->barcodeFilesPath, 0777);
            }

            try {
                $docMissedProductItems = array();
                $docNameNotExist = array();
                $sageVirtualProductReqData['virtual'] = array();
                $sageVirtualProductReqData['bundle'] = array();
                $bundleSkus = array();
                $isProductjsonDataMissed = array();
                $productNotAvilable = array();
                $status = array();

                foreach ($orderItems as $key => $item) {                    
                    $itemData = $item->getData();
                    $productId = $item->getProductId();
                    $productType = $item->getProductType();
                    $productSku = $item->getSku();
                    $qty = (int)$item->getQtyOrdered();

                    
                    $this->itemData[$productSku] = $item->getData();

                    $this->itemData[$productSku]['incrementId'] = $orderId;
                    $this->itemData[$productSku]['orderId'] = $orderId;

                    $productObj = $this->product->setStoreId($item->getStoreId())->load($productId);
                    $productAttachObj = $this->productattachment->load($productObj->getProductAttachment());
                    $docFileName = $productAttachObj->getFile();
                    $docFilePath = $this->mediaPath . $docFileName;

                    $isSerlized = $productObj->getData('isserializeditem');

                    if ($productObj->getData()) {
                        if ($productType == "bundle") {
                            $bundleSkus[$item->getId()]['isPdf'] = $productObj->getData('ni_product_pdf_required');
                            $bundleSkus[$item->getId()]['sku'] = $item->getSku();
                            $bundleSkus[$item->getId()]['docFile'] = $docFilePath;
                            $bundleSkus[$item->getId()]['docName'] = $docFileName;
                            $bundleSkus[$item->getId()]['productId'] = $productId;
                            $bundleSkus[$item->getId()]['isSerialized'] = $isSerlized;
                            $bundleSkus[$item->getId()]['isPdfGropTicket'] = $productObj->getNiPdfGroupTicket();
                            $bundleSkus[$item->getId()]['productJson'] = (array)json_decode($productObj->getProductJsonFormat(), TRUE);
                            if($productObj->getNiPdfGroupTicket()){
                                $this->isPdfGroupTicket[] = $item->getSku();
                            }
                        }

                        if ($productType == "virtual" && $productObj->getData('ni_product_pdf_required') && $item->getParentItemId() == '' && $isSerlized) {
                            if($docFileName){
                                $productAttributeData = (array)json_decode($productObj->getProductJsonFormat(), TRUE);
                                    if(empty($productAttributeData)){
                                        $this->isProductMissedJsonData[] = $item->getSku();
                                    }
                                    #$this->isProductSerialised[$incrementId][$item->getSku()] = $productObj->getSerialno();
                                    if (file_exists($docFilePath) && $docFileName) {
                                        $this->productDocsFilePath[$productSku] = $docFilePath;
                                        $this->totalOrderQty += $qty;
                                        $sageVirtualProductReqData['virtual'][] = $quoteId . ',' . $incrementId . ',' . $productSku . ',' . $qty;
                                    } else {
                                        array_push($docMissedProductItems, $productSku);  #Documents Missed Products List in Array
                                    }
                           }else{
                               array_push($docMissedProductItems, $productSku);
                           }
                        } else {
                            $parentItemId = trim((int)$item->getParentItemId());
                            if ($productType == "virtual" && $parentItemId) {
                                if($bundleSkus[$parentItemId]['docName']){
                                    if($bundleSkus[$parentItemId]['isSerialized']) {
                                        $parentSkuJsonData = $bundleSkus[$parentItemId]['productJson'];
                                        if (empty($bundleSkus[$parentItemId]['productJson'])) {
                                            $this->isProductMissedJsonData[] = $bundleSkus[$parentItemId]['sku'];
                                        }
                                        #$this->isProductSerialised[$incrementId][$bundleSkus[$item->getParentItemId()]['sku']] = $bundleSkus[$item->getParentItemId()]['isSerialized'];
                                        if ($bundleSkus[$parentItemId]['isPdf']) {
                                            if (file_exists($bundleSkus[$parentItemId]['docFile']) && $bundleSkus[$parentItemId]['docName']) {
                                                $this->productDocsFilePath[$bundleSkus[$parentItemId]['sku']] = $bundleSkus[$parentItemId]['docFile'];
                                                $this->totalOrderQty += $qty;
                                                $sageVirtualProductReqData['bundle'][$bundleSkus[$parentItemId]['sku']][] = $quoteId . ',' . $incrementId . ',' . $productSku . ',' . $qty;
                                            } else {
                                                array_push($docMissedProductItems, $bundleSkus[$parentItemId]['sku']);  #Documents Missed Products List in Array
                                            }
                                        }
                                    }
                               }else{
                                array_push($docMissedProductItems, $bundleSkus[$parentItemId]['sku']);
                               }
                            }
                        }
                    } else {
                        array_push($productNotAvilable, $item->getSku());
                    }
                }

                $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                $sageVirtualProductReturnData = array();
                $serialItemsFromTable = array();
                $apiError = '';

                //echo "<pre>"; print_r($sageVirtualProductReqData); exit;
                if (empty($docMissedProductItems) && $sageVirtualProductReqData && empty($productNotAvilable) && empty($isProductjsonDataMissed)) {

                    if($reqType == 'backend'){
                        $serialItemsFromTable['virtual'] = $this->serialCodesExistList($sageVirtualProductReqData['virtual'],'virtual');
                        $serialItemsFromTable['bundle'] = $this->serialCodesExistList($sageVirtualProductReqData['bundle'],'bundle');
                    }

                    if($this->orderSerialCodesQtyFromTable >0) {
                        if ($this->totalOrderQty === $this->orderSerialCodesQtyFromTable) {
                            $this->useSerialCodesFromTable = 1;
                            $this->useSageSerialCodes = 0;
                        }else{
                            $this->serialCodesQtyIssueFromTable = 1;
                            $this->useSageSerialCodes = 0;
                        }
                    }

                    if($this->serialCodesQtyIssueFromTable == 1 && $reqType == 'backend'){
                        $this->errorList['qtymatched'] = "Issue With Serial Sodes Qty issue";
                        $status['status'] = 'error';
                        $status['message'] = $this->errorList;
                        return $status;
                    }

                    $sageRequest = $objectManager->create('\Serole\Sage\Model\Inventory');
                    if (!empty($sageVirtualProductReqData['virtual']) && $this->useSageSerialCodes == 1) {
                        $verTualApiResponse = $sageRequest->getSerilaCodes($sageVirtualProductReqData['virtual']);
                        #$verTualApiResponse = $this->getVirtualSerialCodes($sageVirtualProductReqData['virtual'],'virtual');
                        if ($verTualApiResponse['response'] == "Success") {
                            $sageVirtualProductReturnData['virtual'] = $verTualApiResponse;
                        } else {
                            $apiError .= $verTualApiResponse['message'];
                        }

                    }

                    if (!empty($sageVirtualProductReqData['bundle']) && $this->useSageSerialCodes == 1) {
                        foreach ($sageVirtualProductReqData['bundle'] as $bundleSku => $bundleItems) {
                            $apiBundleResponse = $sageRequest->getSerilaCodes($bundleItems);
                            #$apiBundleResponse = $this->getVirtualSerialCodes($bundleItems,'bundle');
                            if ($apiBundleResponse['response'] == "Success") {
                                $sageVirtualProductReturnData['bundle'][$bundleSku] = $apiBundleResponse;
                            } else {
                                $apiError .= $apiBundleResponse['message'];
                                break;
                            }

                        }
                    }

                    if (!empty($sageVirtualProductReturnData) && $this->useSageSerialCodes == 1) {
                        #Intially saving the ordeid in custom table
                        $presentTime = date("Y-m-d H:i:s");
                        $orderStatusColl = $this->orderPdf->getCollection();
                        $orderStatusColl->addFieldToFilter('order_id',$incrementId);
                        $orderStatusCollData = $orderStatusColl->getData();
                        if(empty($orderStatusCollData)) {
                            $orderPdfObj = $this->orderPdf;
                            $orderPdfObj->setOrderId($incrementId);
                            $orderPdfObj->setStatus('pending');
                            $orderPdfObj->setCreatedAt($presentTime);
                            $orderPdfStatus = $orderPdfObj->save();
                            $orderStatusId = $orderPdfStatus->getId();
                        }else{
                             $orderStatusId = $orderStatusCollData[0]['id'];
                        }

                        foreach ($sageVirtualProductReturnData as $productType => $serialCodeItem) {
                            $filesCreate = $this->createDocument($productType, $serialCodeItem);
                        }

                    }
                    if($this->useSerialCodesFromTable == 1 && $this->serialCodesQtyIssueFromTable == 0){
                        $presentTime = date("Y-m-d H:i:s");
                        $orderStatusColl = $this->orderPdf->getCollection();
                        $orderStatusColl->addFieldToFilter('order_id',$incrementId);
                        $orderStatusColl->getFirstItem();
                        $orderStatusCollData = $orderStatusColl->getData();
                        if(empty($orderStatusColl->getData())) {
                            $orderPdfObj = $this->orderPdf;
                            $orderPdfObj->setOrderId($incrementId);
                            $orderPdfObj->setStatus('pending');
                            $orderPdfObj->setCreatedAt($presentTime);
                            $orderPdfStatus = $orderPdfObj->save();
                            $orderStatusId = $orderPdfStatus->getId();
                        }else{
                           $orderStatusId = $orderStatusCollData[0]['id'];

                        }
                       
                        foreach ($serialItemsFromTable as $productType => $serialCodeItem) {
                            $filesCreate = $this->createDocument($productType, $serialCodeItem);
                        }
                    }
                    if ($apiError != '') {
                        $message = $apiError;
                        $subject = "Api Error";
                        $this->errorList['apierror'] = $message;
                        $this->pdfHelper->sendEmailAdminProductNotExist($empty = '', $incrementId, $message);
                    }
                } else {
                    if ($docMissedProductItems) {
                        $missedProductSku = implode(",", array_unique($docMissedProductItems));
                        $message = "These products are missed the documents";
                        $this->errorList['docmissed'] = $message.','.$missedProductSku;
                        $this->pdfHelper->sendEmailAdminProductNotExist($missedProductSku, $incrementId, $message);
                    } elseif ($productNotAvilable) {
                        $productNotAvilablelist = implode(",", array_unique($productNotAvilable));
                        $message = "These products are not avialbe";
                        $this->errorList['productsmissed'] = $message.','.$productNotAvilablelist;
                        $this->pdfHelper->sendEmailAdminProductNotExist($productNotAvilablelist, $incrementId, $message);
                    }elseif ($isProductjsonDataMissed){
                        $jsonDataNotAvilable = implode(",", array_unique($isProductjsonDataMissed));
                        $message = "Product Json Data Not Missed";
                        $this->errorList['productjsonmissed'] = $message.','.$jsonDataNotAvilable;
                        $this->pdfHelper->sendEmailAdminProductNotExist($jsonDataNotAvilable, $incrementId, $message);
                    }

                }

                $mergedFileName = $incrementId . ".pdf";
                $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
                $connection = $resource->getConnection();
                $tableName = $resource->getTableName('order_item_serialcode');

                $query = '';
                $customerEmail = $customerData['email'];

                if ($this->virtualProductfilesListArray['pdf'] || $this->bundleProductfilesListArray['pdf']) {
                    $this->mergePdf($mergedFileName);
                    if (file_exists($this->mergedPdfFilesPath . '/' . $mergedFileName)) {
                        if($this->useSageSerialCodes == 1) {
                            if (isset($sageVirtualProductReturnData['virtual']['sku'])) {
                                foreach ($sageVirtualProductReturnData['virtual']['sku'] as $virutlSku => $virtualItem) {
                                    foreach ($virtualItem as $virtualSerialCode) {
                                        $serialCodeNo = $virtualSerialCode['SerialNumber'];
                                        $exprieDate = $virtualSerialCode['ExpireDate'];
                                        $pin = $virtualSerialCode['PIN'];
                                        $secondSerialCode = $virtualSerialCode['SecondSerialCode'];
                                        $url = $virtualSerialCode['URL'];
                                        $startDate = $virtualSerialCode['StartDate'];
                                        $value = $virtualSerialCode['Value'];
                                        $query .= "($incrementId,'$virutlSku','','$serialCodeNo','$exprieDate','$pin','$secondSerialCode','$url','$startDate','$value',1,'auto','$customerEmail'),";
                                    }
                                }
                            }
                           if (isset($sageVirtualProductReturnData['bundle'])) {
                                foreach ($sageVirtualProductReturnData['bundle'] as $bundleSku => $bundleSkuItems) {
                                    foreach ($bundleSkuItems['sku'] as $bundleChildSku => $bundleChildItem) {
                                        foreach ($bundleChildItem as $bundleSerialCode) {
                                            $serialCodeNo = $bundleSerialCode['SerialNumber'];
                                            $exprieDate = $bundleSerialCode['ExpireDate'];
                                            $pin = $bundleSerialCode['PIN'];
                                            $secondSerialCode = $bundleSerialCode['SecondSerialCode'];
                                            $url = $bundleSerialCode['URL'];
                                            $startDate = $bundleSerialCode['StartDate'];
                                            $value = $bundleSerialCode['Value'];
                                            $query .= "($incrementId,'$bundleChildSku','$bundleSku','$serialCodeNo','$exprieDate','$pin','$secondSerialCode','$url','$startDate','$value',1,'auto','$customerEmail'),";
                                        }
                                    }
                                }
                            }


                            $queryClean = substr($query, 0, -1); 
                            $sql = "Insert Into " . $tableName . " (OrderID, sku, parentsku, SerialNumber,ExpireDate,PIN,SecondSerialCode,URL,StartDate,Value, status, mode, email)
                                              Values " . $queryClean . ";";
                            $connection->query($sql);
                        }
                        
                        $orderPdfObjUpdate = $this->orderPdf->load($orderStatusId);
                        $updatedTime = date("Y-m-d H:i:s");
                        $orderPdfObjUpdate->setStatus("completed");
                        $orderPdfObjUpdate->setUpdatedAt($updatedTime);
                        $orderPdfObjUpdate->save();
                        
                        $fileUrl = $this->mergedPdfFilesPath . '/' . $mergedFileName;
                        
                        if ($emailStauts) {
                            $mailStatus = $this->pdfHelper->sendPdfToCustomerEmail($fileUrl, $customerData, $incrementId);
                        }
                    }
                }
                if(!empty($this->errorList)){
                    $logger->info("Error's List for order =>".$incrementId);
                    $logger->info($this->errorList);
                    $status['status'] = 'error';
                    $status['message'] = $this->errorList;
                }else{
                    $status['status'] = 'success';
                }
            } catch (\Exception $e) {
                $logger->info($e->getMessage());
            }

        }

        return $status;
    }

    public function serialCodesExistList($serialItemsReqData,$type){
        $result = array();
        if($type == 'virtual'){
            foreach ($serialItemsReqData as $serialItem){
                $stringToArray = explode(',',$serialItem);
                $orderSerialCodesColl = $this->orderItemSerialcode->getCollection();
                $orderSerialCodesColl->addFieldToFilter('OrderID',$stringToArray[1]);
                $orderSerialCodesColl->addFieldToFilter('sku',$stringToArray[2]);
                $orderSerialCodesColl->addFieldToFilter('parentsku','');
                $orderSerialCodesColl->addFieldToFilter('status',1);
                $result['sku'][$stringToArray[2]] = $orderSerialCodesColl->getData();
                $this->orderSerialCodesQtyFromTable += count($orderSerialCodesColl->getData());
            }
        }
        if($type == 'bundle'){
            foreach ($serialItemsReqData as $bundleSku => $bundleSerialItem){
                foreach ($bundleSerialItem as $childSerialItem){
                    $stringToArrayBundle = explode(',',$childSerialItem);
                    $orderBSerialCodesColl = $this->orderItemSerialcode->getCollection();
                    $orderBSerialCodesColl->addFieldToFilter('OrderID',$stringToArrayBundle[1]);
                    $orderBSerialCodesColl->addFieldToFilter('sku',$stringToArrayBundle[2]);
                    $orderBSerialCodesColl->addFieldToFilter('parentsku',$bundleSku);
                    $orderBSerialCodesColl->addFieldToFilter('status',1);
                    $result[$bundleSku]['sku'][$stringToArrayBundle[2]] = $orderBSerialCodesColl->getData();
                    $this->orderSerialCodesQtyFromTable += (int)count($orderBSerialCodesColl->getData());
                }
            }
        }
        return $result;
    }

    /*method for crating docuemnt*/
    public function createDocument($productType,$serialCodeDatas){
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/pdf-create-createDocument.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        try {
            if(!empty($serialCodeDatas)){
                if($productType == 'bundle'){
                    foreach ($serialCodeDatas as $bundleSku => $bundleItemData) {
                        $this->createBundleProductDoc($bundleSku, $bundleItemData['sku']);
                    }
                }
                if($productType == 'virtual'){
                    foreach ($serialCodeDatas['sku'] as $productSku => $virutalItemData) {
                        $this->createVirtualProductDoc($productSku, $virutalItemData);
                    }
                }
            }
        } catch (\Exception $e) {
            $logger->info($e->getMessage());
            $status = FALSE;
        }

    }

    protected function createBundleProductDoc($bundleSku,$bundleItemData){
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/pdf-create-createBundleProductDoc.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        try {
            $bundleSkusearchResult = array_search($bundleSku,$this->isPdfGroupTicket);
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $productRepository = $objectManager->create('\Magento\Catalog\Model\ProductRepository');
            $productObj = $productRepository->get($bundleSku);

            $productAttributeJsonData = $productObj->getProductJsonFormat();
            $productAttributeData = (array)json_decode($productAttributeJsonData, TRUE);
            $productCustomOptions = $this->productOptions->getProductOptionCollection($productObj);

            $docFilePath = $this->productDocsFilePath[$bundleSku];

            $docsSaveFilename = "ticket-" . $this->orderId . '-' . $bundleSku . ".docx";
            $pdfFilename = "ticket-" . $this->orderId . '-' . $bundleSku . ".pdf";
            $serialCodeItemsCount = 0;

            $isGroupTicket = array_search($bundleSku,$this->isPdfGroupTicket);

            if(is_numeric($isGroupTicket)){
                $this->bunldeGroupTicketCreate($bundleSku,$bundleItemData,$productAttributeData,$docFilePath,
                                               $productObj,$productCustomOptions,$docsSaveFilename,$pdfFilename);

            }else{
                $this->bundeTicket($bundleSku,$bundleItemData,$productAttributeData,$docFilePath,
                                   $productObj,$productCustomOptions);
            }


        }catch (\Exception $e){
            $logger->info($e->getMessage());
        }
    }

    public function bundeTicket($bundleSku,$bundleItemData,$productAttributeData,$docFilePath,
                                $productObj,$productCustomOptions){

        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/pdf-create-bundeTicket-NonGroupTicket.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        //echo "<pre>"; print_r($this->itemData[$bundleSku]); exit;
        try{
            foreach ($bundleItemData as $budleItems){
                foreach ($budleItems as $budleItem){
                    $docsSaveFilename = "ticket-" . $this->orderId . '-' . $bundleSku .'-'. $budleItem['SerialNumber'].".docx";
                    $pdfFilename = "ticket-" . $this->orderId . '-' . $bundleSku .'-'. $budleItem['SerialNumber']. ".pdf";

                    $templateProcessor = new \PhpOffice\PhpWord\TemplateProcessor($docFilePath);
                    $templateProcessor->cloneRow('sno', 1);

                    $templateProcessor->setValue('sno#1', '1');
                    
                      foreach ($productAttributeData as $productAttributeItem) {
                          if ($productAttributeItem['type'] == 'image') {
                              if ($productAttributeItem['source'] == 'attribute') {
                                  $attributeVariableData = $productObj->getData($productAttributeItem['variable']);
                                  if (!$attributeVariableData) {
                                      $templateProcessor->setValue($productAttributeItem['variable'], ' ');
                                  } else {
                                      $templateProcessor->setValue($productAttributeItem['variable'], $attributeVariableData);
                                      # set image here
                                  }
                              } elseif ($productAttributeItem['source'] == 'customOption') {
                                if(isset($this->itemData[$bundleSku]['product_options']['options'])){  
                                  $width = 100;
                                  $height = 100;
                                  if (isset($productAttributeItem['width'])) {
                                      $width = $productAttributeItem['width'];
                                  }
                                  if (isset($productAttributeItem['height'])) {
                                      $height = $productAttributeItem['height'];
                                  }

                                  $orderItemCustomOptions = $this->itemData[$bundleSku]['product_options']['options'];
                                  $key = array_search($productAttributeItem['variable'], array_column($orderItemCustomOptions, 'label'));
                                  if (is_numeric($key)) {
                                       $customOptionData = json_decode($orderItemCustomOptions[$key]['option_value'], true);
                                       $customOptionImagepath = $customOptionData['fullpath'];
                                       if (file_exists($customOptionImagepath)) {
                                             $templateProcessor->setImg($productAttributeItem['variable'], array('src' => $customOptionImagepath, 'size' => array($width, $height)));
                                  }
                                  } else {
                                       $templateProcessor->setValue($productAttributeItem['variable'], ' ');
                                  }
                                }
                              } elseif ($productAttributeItem['source'] == 'logo') {
                                  $width = 100;
                                  $height = 100;
                                  if (isset($productAttributeItem['width'])) {
                                      $width = $productAttributeItem['width'];
                                  }
                                  if (isset($productAttributeItem['height'])) {
                                      $height = $productAttributeItem['height'];
                                  }
                                  $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                                  $mediaPath = $this->pdfHelper->getMediaBaseDir();
                                  $scopeConfig = $objectManager->create('Magento\Framework\App\Config\ScopeConfigInterface');
                                  $configPath = "design/header/logo_src";
                                  $filename = $scopeConfig->getValue($configPath,
                                      \Magento\Store\Model\ScopeInterface::SCOPE_STORE
                                  );
                                  $imagePath = $mediaPath . 'logo/' . $filename;
                                  //$logger->info("Ramesh".$imagePath);
                                  if (file_exists($imagePath)) {
                                      $templateProcessor->setImg($productAttributeItem['variable'], array('src' => $imagePath, 'size' => array($width, $height)));
                                  } else {
                                      $templateProcessor->setValue($productAttributeItem['variable'], ' ');
                                  }
                              }
                          } elseif ($productAttributeItem['type'] == 'text') {
                            //echo "<pre>"; print_r($productAttributeItem); exit;
                              if ($productAttributeItem['source'] == 'attribute') {
                                  $attributeVariableData = $productObj->getData($productAttributeItem['variable']);
                                  if (!$attributeVariableData) {
                                      $templateProcessor->setValue($productAttributeItem['variable'], ' ');
                                  }else {
                                      $templateProcessor->setValue($productAttributeItem['variable'], $attributeVariableData);
                                  }
                              }elseif ($productAttributeItem['source'] == 'serialCode'){
                                  $attributeVariableData = $budleItem[$productAttributeItem['variable']];
                                  if (!$attributeVariableData) {
                                      $templateProcessor->setValue($productAttributeItem['variable'] . '#1', ' ');
                                  }else {
                                      $templateProcessor->setValue($productAttributeItem['variable'] . '#1', $attributeVariableData);
                                  }
                              }elseif ($productAttributeItem['source'] == 'orderData'){
                                  $attributeVariableData = $this->itemData[$bundleSku][$productAttributeItem['variable']];
                                  if (!$attributeVariableData) {
                                      $templateProcessor->setValue($productAttributeItem['variable'], ' ');
                                  }else{
                                      $templateProcessor->setValue($productAttributeItem['variable'], $attributeVariableData);
                                  }
                              }elseif ($productAttributeItem['source'] == 'customOption') {
                               //echo "123"; print_r($productAttributeItem);               
                               if(isset($this->itemData[$bundleSku]['product_options']['options'])){                 
                                  $orderItemCustomOptions = $this->itemData[$bundleSku]['product_options']['options'];
                                  $key = array_search($productAttributeItem['variable'], array_column($orderItemCustomOptions, 'label'));
                                  if (is_numeric($key)) {
                                      $customOptionVariableData = $orderItemCustomOptions[$key]['value'];
                                      $templateProcessor->setValue($productAttributeItem['variable'], $customOptionVariableData);
                                  } else {
                                      $templateProcessor->setValue($productAttributeItem['variable'], ' ');
                                  }
                                }else{
                                   $templateProcessor->setValue($productAttributeItem['variable'], ' ');
                               }
                              }                              
                          } elseif ($productAttributeItem['type'] == 'date') {
                              if ($productAttributeItem['source'] == 'other') {
                                  if (!$productAttributeItem['duration']) {
                                      $logger->info("Date Duration not valid ".$this->orderId .' product sku '.$bundleSku);
                                  }
                                  $currentDate = $this->date->gmtDate();
                                  $expDate = '';
                                  $dateData = explode('_', $productAttributeItem['duration']);
                                  $logger->info($dateData);
                                  if ($dateData[1] == 'M') {
                                      $expDate = date('Y-m-d', strtotime($currentDate . '+ ' . $dateData[0] . " months"));
                                  } elseif ($dateData[1] == 'D') {
                                      $expDate = date('Y-m-d', strtotime($currentDate . '+ ' . $dateData[0] . " days"));
                                  } elseif ($dateData[1] == 'Y') {
                                      $expDate = date('Y-m-d', strtotime($currentDate . '+ ' . $dateData[0] . " years"));
                                  } else {
                                      $logger->info("Something wrong about Date Duration ".$this->orderId .' product sku '.$bundleSku);
                                  }
                                  if (!$expDate) {
                                      $templateProcessor->setValue($productAttributeItem['variable'], ' ');
                                  }else {
                                      $templateProcessor->setValue($productAttributeItem['variable'], $expDate);
                                  }
                              }
                          }elseif ($productAttributeItem['type'] == 'barcode') {
                              $barwidth = 100;
                              $barheight = 200;
                              $docImagewidth = 250;
                              $docImageheight = 100;

                              if (isset($productAttributeItem['barwidth']) && $productAttributeItem['barwidth'] > 0) {
                                  $barwidth = $productAttributeItem['barwidth'];
                              }
                              if (isset($productAttributeItem['barheight']) && $productAttributeItem['barheight'] > 0) {
                                  $barheight = $productAttributeItem['barheight'];
                              }
                              if (isset($productAttributeItem['width']) && $productAttributeItem['width'] > 0) {
                                  $docImagewidth = $productAttributeItem['width'];
                              }
                              if (isset($productAttributeItem['height']) && $productAttributeItem['height'] > 0) {
                                  $docImageheight = $productAttributeItem['height'];
                              }

                              $barcodeSaveFileName = "barcode-" . $budleItem['OrderID'] . '-item-' . trim($budleItem['SerialNumber']) . ".png";
                              $barcodeFilePath = $this->barCodeCreate($barcodeSaveFileName, $budleItem['SerialNumber'], $barwidth, $barheight);
                              if (file_exists($barcodeFilePath)) {
                                  $barCodeFileName = $barcodeSaveFileName;
                                  $templateProcessor->setImg('barcode' . '#1', array('src' => $barcodeFilePath, 'size' => array($docImagewidth, $docImageheight)));  //Width&height
                              }else{
                                  $logger->info(" Bar Code is missed ".$this->orderId." Product ".$bundleSku);
                                  $templateProcessor->setValue('barcode', ' ');
                              }
                          } elseif ($productAttributeItem['type'] == 'cdate') {
                              if ($productAttributeItem['source'] == 'other') {
                                  $currentDate = $this->date->gmtDate();
                                  $templateProcessor->setValue($productAttributeItem['variable'], $currentDate);
                              }
                          }

                      }

                    $templateProcessor->saveAs($this->temporaryDocFilesPath . '/' . $docsSaveFilename);
                    if (file_exists($this->temporaryDocFilesPath . '/' . $docsSaveFilename)) {
                        array_push($this->bundleProductfilesListArray['doc'], $this->temporaryDocFilesPath . '/' . $docsSaveFilename);
                        /*Creating PDF for bundle product*/
                        $pdfSaveFilename = $this->createPdf($this->temporaryDocFilesPath, $docsSaveFilename, $this->temporaryPdfFilesPath, $pdfFilename);
                        if ($pdfSaveFilename) {
                            array_push($this->bundleProductfilesListArray['pdf'], $this->temporaryPdfFilesPath . '/' . $pdfFilename);
                        }
                    } else {
                        $logger->info("Bundle Ticket Document Doest exit" . $docsSaveFilename);
                    }
                }
            }
        }catch (\Exception $e){
            $logger->info($e->getMessage());
        }

    }



    public function bunldeGroupTicketCreate($bundleSku,$bundleItemData,$productAttributeData,$docFilePath,
                                            $productObj,$productCustomOptions,$docsSaveFilename,$pdfFilename){
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/pdf-create-bunldeGroupTicketCreate.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        //echo "Bundle "; exit;
        //echo "<pre>"; print_r($productAttributeData); exit;
        try {
            $serialCodeItemsCount = 0;
            foreach ($bundleItemData as $bundleChilds) {
                $serialCodeItemsCount += count($bundleChilds);
            }

            $templateProcessor = new \PhpOffice\PhpWord\TemplateProcessor($docFilePath);

            foreach ($productAttributeData as $productAttributeItem) {
                if ($productAttributeItem['type'] == 'image') {
                    if ($productAttributeItem['source'] == 'attribute') {
                        $attributeVariableData = $productObj->getData($productAttributeItem['variable']);
                        if (!$attributeVariableData) {
                            $templateProcessor->setValue($productAttributeItem['variable'], ' ');
                        } else {
                            $templateProcessor->setValue($productAttributeItem['variable'], $attributeVariableData);
                            # Set Image Here
                        }
                    } elseif ($productAttributeItem['source'] == 'customOption') {
                        if(isset($this->itemData[$bundleSku]['product_options']['options'])){  
                            $width = 100;
                            $height = 100;
                            if (isset($productAttributeItem['width'])) {
                                $width = $productAttributeItem['width'];
                            }
                            if (isset($productAttributeItem['height'])) {
                                $height = $productAttributeItem['height'];
                            }
                            $orderItemCustomOptions = $this->itemData[$bundleSku]['product_options']['options'];
                            $key = array_search($productAttributeItem['variable'], array_column($orderItemCustomOptions, 'label'));
                            if (is_numeric($key)) {
                                $customOptionData = json_decode($orderItemCustomOptions[$key]['option_value'], true);
                                $customOptionImagepath = $customOptionData['fullpath'];
                                if (file_exists($customOptionImagepath)) {
                                    $templateProcessor->setImg($productAttributeItem['variable'], array('src' => $customOptionImagepath, 'size' => array($width, $height)));
                                }
                            } else {
                               $templateProcessor->setValue($productAttributeItem['variable'], ' ');
                            }
                      }  
                    } elseif ($productAttributeItem['source'] == 'logo') {
                        //echo "Into Log";
                        $width = 100;
                        $height = 100;
                        if (isset($productAttributeItem['width'])) {
                            $width = $productAttributeItem['width'];
                        }
                        if (isset($productAttributeItem['height'])) {
                            $height = $productAttributeItem['height'];
                        }
                        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                        $mediaPath = $this->pdfHelper->getMediaBaseDir();
                        $scopeConfig = $objectManager->create('Magento\Framework\App\Config\ScopeConfigInterface');
                        $configPath = "design/header/logo_src";
                        $filename = $scopeConfig->getValue($configPath,
                            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
                        );
                        $imagePath = $mediaPath . 'logo/' . $filename;
                        if (file_exists($imagePath)) {
                            //echo $imagePath;
                            $templateProcessor->setImg($productAttributeItem['variable'], array('src' => $imagePath, 'size' => array($width, $height)));
                        } else {
                            $templateProcessor->setValue($productAttributeItem['variable'], ' ');
                        }
                    }
                } elseif ($productAttributeItem['type'] == 'text') {
                    if ($productAttributeItem['source'] == 'attribute') {
                        $attributeVariableData = $productObj->getData($productAttributeItem['variable']);
                        if (!$attributeVariableData) {
                            $templateProcessor->setValue($productAttributeItem['variable'], ' ');
                        }else{
                            $templateProcessor->setValue($productAttributeItem['variable'], $attributeVariableData);
                        }
                    }elseif ($productAttributeItem['source'] == 'orderData'){
                        $attributeVariableData = $this->itemData[$bundleSku][$productAttributeItem['variable']];
                        if (!$attributeVariableData) {
                            $templateProcessor->setValue($productAttributeItem['variable'], ' ');
                        }else{
                            $templateProcessor->setValue($productAttributeItem['variable'], $attributeVariableData);
                        }
                    }elseif ($productAttributeItem['source'] == 'customOption') {
                        if(isset($this->itemData[$bundleSku]['product_options']['options'])){  
                             $orderItemCustomOptions = $this->itemData[$bundleSku]['product_options']['options'];
                             $key = array_search($productAttributeItem['variable'], array_column($orderItemCustomOptions, 'label'));
                             if (is_numeric($key)) {
                                  $customOptionVariableData = $orderItemCustomOptions[$key]['value'];
                                  $templateProcessor->setValue($productAttributeItem['variable'], $customOptionVariableData);
                             } else {
                                  $templateProcessor->setValue($productAttributeItem['variable'], ' ');
                             }
                       }else{
                            $templateProcessor->setValue($productAttributeItem['variable'], ' ');
                        }
                    }
                } elseif ($productAttributeItem['type'] == 'date') {
                    if ($productAttributeItem['source'] == 'other') {
                        if (!$productAttributeItem['duration']) {
                            $logger->info("Date Duration not valid ".$this->orderId .'=>'.$bundleSku);
                        }
                        $currentDate = $this->date->gmtDate();
                        $expDate = '';
                        $dateData = explode('_', $productAttributeItem['duration']);
                        $logger->info($dateData);
                        if ($dateData[1] == 'M') {
                            $expDate = date('Y-m-d', strtotime($currentDate . '+ ' . $dateData[0] . " months"));
                        } elseif ($dateData[1] == 'D') {
                            $expDate = date('Y-m-d', strtotime($currentDate . '+ ' . $dateData[0] . " days"));
                        } elseif ($dateData[1] == 'Y') {
                            $expDate = date('Y-m-d', strtotime($currentDate . '+ ' . $dateData[0] . " years"));
                        } else {
                            $logger->info("Something wrong about Date Duration ".$this->orderId .'=>'.$bundleSku);
                        }
                        if (!$expDate) {
                            $templateProcessor->setValue($productAttributeItem['variable'], ' ');
                        }else {
                            $templateProcessor->setValue($productAttributeItem['variable'], $expDate);
                        }
                    }
                }
            }

            $templateProcessor->cloneRow('sno', $serialCodeItemsCount);

            $i = 1;
            foreach ($bundleItemData as $budleItems) {
                foreach ($budleItems as $budleItem) {
                    foreach ($productAttributeData as $productAttributeItem) {
                        $templateProcessor->setValue('sno' . '#' . $i, $i);
                        if ($productAttributeItem['type'] == 'text') {                            
                            if ($productAttributeItem['source'] == 'serialCode') {
                                $attributeVariableData = $budleItem[$productAttributeItem['variable']];
                                if (!$attributeVariableData) {
                                    $templateProcessor->setValue($productAttributeItem['variable'] . '#' . $i, ' ');
                                }else {
                                    $templateProcessor->setValue($productAttributeItem['variable'] . '#' . $i, $attributeVariableData);
                                }
                            }
                        } elseif ($productAttributeItem['type'] == 'barcode') {
                            $barwidth = 100;
                            $barheight = 200;
                            $docImagewidth = 250;
                            $docImageheight = 100;

                            if (isset($productAttributeItem['barwidth']) && $productAttributeItem['barwidth'] > 0) {
                                $barwidth = $productAttributeItem['barwidth'];
                            }
                            if (isset($productAttributeItem['barheight']) && $productAttributeItem['barheight'] > 0) {
                                $barheight = $productAttributeItem['barheight'];
                            }
                            if (isset($productAttributeItem['width']) && $productAttributeItem['width'] > 0) {
                                $docImagewidth = $productAttributeItem['width'];
                            }
                            if (isset($productAttributeItem['height']) && $productAttributeItem['height'] > 0) {
                                $docImageheight = $productAttributeItem['height'];
                            }

                            $barcodeSaveFileName = "barcode-" . $budleItem['OrderID'] . '-item-' . trim($budleItem['SerialNumber']) . ".png";
                            $barcodeFilePath = $this->barCodeCreate($barcodeSaveFileName, $budleItem['SerialNumber'], $barwidth, $barheight);
                            if (file_exists($barcodeFilePath)) {
                                $barCodeFileName = $barcodeSaveFileName;
                                $templateProcessor->setImg('barcode' . '#' . $i, array('src' => $barcodeFilePath, 'size' => array($docImagewidth, $docImageheight)));  //Width&height
                            }else{
                                $logger->info("Bar Code not exist for".$this->orderId .' product is '.$bundleSku);
                                $templateProcessor->setValue('barcode', ' ');
                            }
                        } elseif ($productAttributeItem['type'] == 'cdate') {
                            if ($productAttributeItem['source'] == 'other') {
                                $currentDate = $this->date->gmtDate();
                                $templateProcessor->setValue($productAttributeItem['variable'], $currentDate);
                            }
                        }
                    }
                    $i++;
                }

            }
            $templateProcessor->saveAs($this->temporaryDocFilesPath . '/' . $docsSaveFilename);
            if (file_exists($this->temporaryDocFilesPath . '/' . $docsSaveFilename)) {
                array_push($this->bundleProductfilesListArray['doc'], $this->temporaryDocFilesPath . '/' . $docsSaveFilename);
                /*Creating PDF for bundle product*/
                $pdfSaveFilename = $this->createPdf($this->temporaryDocFilesPath, $docsSaveFilename, $this->temporaryPdfFilesPath, $pdfFilename);
                if ($pdfSaveFilename) {
                    array_push($this->bundleProductfilesListArray['pdf'], $this->temporaryPdfFilesPath . '/' . $pdfFilename);
                }
            } else {
                $logger->info("Bundle Ticket Document Doest exit" . $docsSaveFilename);
            }
        }catch (\Exception $e){
            $logger->info($e->getMessage());
        }
    }

    protected function createVirtualProductDoc($productSku,$serialItems){

        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/pdf-reate-createVirtualProductDoc.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);

        //echo $productSku;
        //print_r($serialItems); exit;

        try {
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $productRepository = $objectManager->get('\Magento\Catalog\Model\ProductRepository');
            $productObj = $productRepository->get($productSku);

            $productAttributeJsonData = $productObj->getProductJsonFormat();
            $productAttributeData = (array)json_decode($productAttributeJsonData, TRUE);

            $docFilePath = $this->productDocsFilePath[$productSku];

            //echo "<pre>"; print_r($productAttributeData); exit;

            foreach ($serialItems as $serialItem) {
                $docsSaveFilename = "ticket-" . $serialItem['OrderID'] . '-' . trim($serialItem['SerialNumber']) . "-document.docx";
                $pdfFilename = "ticket-" . $serialItem['OrderID'] . '-' . trim($serialItem['SerialNumber']) . "-pdffile.pdf";
                $templateProcessor = new \PhpOffice\PhpWord\TemplateProcessor($docFilePath);
                foreach ($productAttributeData as $productAttributeItem) {
                    if ($productAttributeItem['type'] == 'image') {
                        if ($productAttributeItem['source'] == 'attribute') {
                            $attributeVariableData = $productObj->getData($productAttributeItem['variable']);
                            if (!$attributeVariableData) {
                                $templateProcessor->setValue($productAttributeItem['variable'], ' ');
                            }else {
                                $templateProcessor->setValue($productAttributeItem['variable'], $attributeVariableData);
                                # Set Image Here
                            }
                        } elseif ($productAttributeItem['source'] == 'customOption') {
                            if(isset($this->itemData[$productSku]['product_options']['options'])){  
                                $width = 100;
                                $height = 100;
                                if (isset($productAttributeItem['width'])) {
                                    $width = $productAttributeItem['width'];
                                }
                                if (isset($productAttributeItem['height'])) {
                                    $height = $productAttributeItem['height'];
                                }
                                $orderItemCustomOptions = $this->itemData[$productSku]['product_options']['options'];
                                $key = array_search($productAttributeItem['variable'], array_column($orderItemCustomOptions, 'label'));
                                if (is_numeric($key)) {
                                   $customOptionData = json_decode($orderItemCustomOptions[$key]['option_value'], true);
                                   $customOptionImagepath = $customOptionData['fullpath'];
                                   if (file_exists($customOptionImagepath)) {
                                      $templateProcessor->setImg($productAttributeItem['variable'], array('src' => $customOptionImagepath, 'size' => array($width, $height)));
                                   }
                                } else {
                                  $templateProcessor->setValue($productAttributeItem['variable'], ' ');
                                }
                          }  
                        } elseif ($productAttributeItem['source'] == 'logo') {
                            $width = 150;
                            $height = 150;
                            if (isset($productAttributeItem['width'])) {
                                $width = $productAttributeItem['width'];
                            }
                            if (isset($productAttributeItem['height'])) {
                                $height = $productAttributeItem['height'];
                            }
                            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                            $mediaPath = $this->pdfHelper->getMediaBaseDir();
                            $scopeConfig = $objectManager->create('Magento\Framework\App\Config\ScopeConfigInterface');
                            $configPath = "design/header/logo_src";
                            $filename = $scopeConfig->getValue($configPath, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
                            $logger->info("Logo image name" . $filename);
                            $imagePath = $mediaPath . 'logo/' . $filename;
                            //echo $imagePath;
                            $logger->info("Image Path" . $imagePath);
                            if (file_exists($imagePath)) {
                                $templateProcessor->setImg($productAttributeItem['variable'], array('src' => $imagePath, 'size' => array($width, $height)));
                            } else {
                                $templateProcessor->setValue($productAttributeItem['variable'], ' ');
                            }
                        }
                    } elseif ($productAttributeItem['type'] == 'text') {
                        if ($productAttributeItem['source'] == 'attribute') {
                            $attributeVariableData = $productObj->getData($productAttributeItem['variable']);
                            if (!$attributeVariableData) {
                                $templateProcessor->setValue($productAttributeItem['variable'], ' ');
                            }else{
                                $templateProcessor->setValue($productAttributeItem['variable'], $attributeVariableData);
                            }
                        } elseif ($productAttributeItem['source'] == 'serialCode') {
                            $serialCodeNumber = trim($serialItem[$productAttributeItem['variable']]);
                            $attributeVariableData = $serialCodeNumber;
                            if (!$attributeVariableData) {
                                $templateProcessor->setValue($productAttributeItem['variable'], ' ');
                            }else {
                                $templateProcessor->setValue($productAttributeItem['variable'], $attributeVariableData);
                            }
                        } elseif ($productAttributeItem['source'] == 'customOption') {
                            /*$itemData is the order Data*/
                            if(isset($this->itemData[$productSku]['product_options']['options'])){ 
                                $orderItemCustomOptions = $this->itemData[$productSku]['product_options']['options'];
                                $key = array_search($productAttributeItem['variable'], array_column($orderItemCustomOptions, 'label'));
                                if (is_numeric($key)) {
                                     $customOptionVariableData = $orderItemCustomOptions[$key]['value'];
                                     $templateProcessor->setValue($productAttributeItem['variable'], $customOptionVariableData);
                                } else {
                                     $templateProcessor->setValue($productAttributeItem['variable'], ' ');
                                }
                           }else{
                                $templateProcessor->setValue($productAttributeItem['variable'], ' ');
                            }
                        }elseif ($productAttributeItem['source'] == 'orderData'){
                            $attributeVariableData = $this->itemData[$productSku][$productAttributeItem['variable']];
                            if (!$attributeVariableData) {
                                $templateProcessor->setValue($productAttributeItem['variable'], ' ');
                            }else{
                                $templateProcessor->setValue($productAttributeItem['variable'], $attributeVariableData);
                            }
                        }
                    } elseif ($productAttributeItem['type'] == 'barcode') {
                        $barwidth = 100;
                        $barheight = 70;
                        $docImagewidth = 150;
                        $docImageheight = 100;

                        $serialCodeNumber = trim($serialItem['SerialNumber']);

                        if (isset($productAttributeItem['barwidth']) && $productAttributeItem['barwidth'] > 0) {
                            $barwidth = $productAttributeItem['barwidth'];
                        }
                        if (isset($productAttributeItem['barheight']) && $productAttributeItem['barheight'] > 0) {
                            $barheight = $productAttributeItem['barheight'];
                        }
                        if (isset($productAttributeItem['width']) && $productAttributeItem['width'] > 0) {
                            $docImagewidth = $productAttributeItem['width'];
                        }
                        if (isset($productAttributeItem['height']) && $productAttributeItem['height'] > 0) {
                            $docImageheight = $productAttributeItem['height'];
                        }

                        $barcodeSaveFileName = "barcode-" . $serialItem['OrderID'] . '-item-' . $serialCodeNumber . ".png";
                        $barcodeFilePath = $this->barCodeCreate($barcodeSaveFileName, $serialCodeNumber, $barwidth, $barheight);
                        if (file_exists($barcodeFilePath)) {
                            $templateProcessor->setImg('barcode', array('src' => $barcodeFilePath, 'size' => array($docImagewidth, $docImageheight)));  /*Width&height*/
                            $status['barcode'] = $barcodeSaveFileName;
                        }else{
                            $logger->info("Bar Code not exist for".$this->orderId .' product is '.$productSku);
                            $templateProcessor->setValue('barcode', ' ');
                        }
                    } elseif ($productAttributeItem['type'] == 'date') {
                        if ($productAttributeItem['source'] == 'other') {
                            if (!isset($productAttributeItem['duration'])) {
                                $logger->info("Date Duration not valid ".$this->orderId .'=>'.$productSku);
                            }
                            $currentDate = $this->date->gmtDate();
                            $expDate = '';
                            $dateData = explode('_', $productAttributeItem['duration']);
                            $logger->info($dateData);
                            if ($dateData[1] == 'M') {
                                $expDate = date('Y-m-d', strtotime($currentDate . '+ ' . $dateData[0] . " months"));
                            } elseif ($dateData[1] == 'D') {
                                $expDate = date('Y-m-d', strtotime($currentDate . '+ ' . $dateData[0] . " days"));
                            } elseif ($dateData[1] == 'Y') {
                                $expDate = date('Y-m-d', strtotime($currentDate . '+ ' . $dateData[0] . " years"));
                            } else {
                                $logger->info("Something wrong about Date Duration " .$this->orderId .'=>'.$productSku);
                            }
                            if (!$expDate) {
                                $templateProcessor->setValue($productAttributeItem['variable'], ' ');
                            }else {
                                $templateProcessor->setValue($productAttributeItem['variable'], $expDate);
                            }
                        }
                    } elseif ($productAttributeItem['type'] == 'cdate') {
                        if ($productAttributeItem['source'] == 'other') {
                            $currentDate = $this->date->gmtDate();
                            $templateProcessor->setValue($productAttributeItem['variable'], $currentDate);
                        }
                    }
                }

                $templateProcessor->saveAs($this->temporaryDocFilesPath . '/' . $docsSaveFilename);
                if (file_exists($this->temporaryDocFilesPath . '/' . $docsSaveFilename)) {
                    //array_push($this->virtualProductfilesListArray['doc'], $serialCodeNumber);
                    $pdfFileCreate = $this->createPdf($this->temporaryDocFilesPath, $docsSaveFilename, $this->temporaryPdfFilesPath, $pdfFilename);
                    if (file_exists($this->temporaryPdfFilesPath . '/' . $pdfFilename)) {
                        array_push($this->virtualProductfilesListArray['pdf'], $this->temporaryPdfFilesPath . '/' . $pdfFilename);
                    }
                } else {
                    array_push($this->virtualProductfilesListArray['doc'], false);
                }

            }
        }catch (\Exception $e){
            $logger->info($e->getMessage());
        }
    }

    /* method for creating barcodes*/
    protected function barCodeCreate($barcodeSaveFileName,$serialcode,$barwidth,$barheight){

        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/pdf-create-barcodecreate.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);

       try{
           /*
             //$barcodeOptions = array('text' => $barCodeNo, 'width'=> '400', 'height'=> '500');
           //$rendererOptions = array('top');
            /* $imageResource = Zend_Barcode::factory('code39', 'image', $barcodeOptions, $rendererOptions)
                 ->setVerticalPosition('middle')
                 ->setHeight($barwidth)
                 ->setWidth($barwidth)
                 ->draw();
             imagepng($imageResource,$filename);
           //->setVerticalPosition('middle')
           //->setHeight($barheight)->setWidth($barwidth)->draw();

           */

            $barcodeOptions = array('text' => $serialcode,'barHeight'=> $barheight);
            $logger->info($barheight);

            $rendererOptions = array(
                //'topOffset' => 10,
                //'leftOffset' => 10,
            );
            $imageResource = Zend_Barcode::factory('code39', 'image', $barcodeOptions, $rendererOptions)->draw();
            $filename = $this->barcodeFilesPath.$barcodeSaveFileName;
            imagepng($imageResource,$filename);
            return $this->barcodeFilesPath.$barcodeSaveFileName;
        }catch (\Exception $e){
            $logger->info("Issue creation barcode for ".$barcodeSaveFileName.' Order is '.$this->orderId."Error Messsage ".$e->getMessage());
        }
    }

    /*method for creating pdf file based on word document*/
    public function createPdf($docFileTemporaryPath,$docTemporaryFileName,$pdfDirectoryPath,$pdfSaveFilename){
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/pdf-create-createPdf.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);

        try {
            if (file_exists($docFileTemporaryPath . '/' . $docTemporaryFileName)) {
                /*
                 $document = new \Gears\Pdf($docFileTemporaryPath . '/' . $docTemporaryFileName);
                 $document->converter = function () {
                     return new \Gears\Pdf\Docx\Converter\Unoconv();
                 };
                 $document->save($pdfDirectoryPath . '/' . $pdfSaveFilename);
               */
                \Gears\Pdf::convert($docFileTemporaryPath . '/' . $docTemporaryFileName, $pdfDirectoryPath . '/' . $pdfSaveFilename);

                if(file_exists($pdfDirectoryPath . '/' . $pdfSaveFilename)) {
                    chmod($docFileTemporaryPath . '/' . $docTemporaryFileName,0777);
                    //unlink($templacePath . '/' . $docsSaveFilename);
                    $status = true;
                }else{
                    $status = false;
                }
            }
        } catch (\Exception $e) {
            $status = false;
            $logger->info("Error at Pdf Creation ".$pdfSaveFilename.' Order is '.$this->orderId."Error Messsage ".$e->getMessage());
        }
        return $status;
    }
    /*method for merging all pdf files*/
    public function mergePdf($mergedFileName){
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/pdf-create-mergePdf.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $status = '';
        try{
            if($this->bundleProductfilesListArray['pdf'] || $this->virtualProductfilesListArray['pdf']) {
                $pdfMerged = new \Zend_Pdf();
                if ($this->virtualProductfilesListArray['pdf']){
                    foreach ($this->virtualProductfilesListArray['pdf'] as $key => $virtualPdfFileItem){
                        if (file_exists($virtualPdfFileItem)) {
                            $logger->info($virtualPdfFileItem);
                            $pdf = \Zend_Pdf::load($virtualPdfFileItem);
                            foreach ($pdf->pages as $page) {
                                $clonedPage = clone $page;
                                $pdfMerged->pages[] = $clonedPage;
                            }
                        }
                    }

                }

                if($this->bundleProductfilesListArray['pdf']){
                    foreach ($this->bundleProductfilesListArray['pdf'] as $key => $bundlePdfFileitem) {
                        if (file_exists($bundlePdfFileitem)) {
                            $logger->info($bundlePdfFileitem);
                            $pdf = \Zend_Pdf::load($bundlePdfFileitem);
                            foreach ($pdf->pages as $page) {
                                $clonedPage = clone $page;
                                $pdfMerged->pages[] = $clonedPage;
                            }
                        }
                    }
                }
                unset($clonedPage);
                $pdfMerged->save($this->mergedPdfFilesPath.'/'.$mergedFileName);
                $status = TRUE;
            }
        }catch (\Exception $e){
            $logger->info("Error at Pdf Merger:- ".$mergedFileName.' Order is '.$this->orderId."Error Messsage ".$e->getMessage());
            $status = FALSE;
        }
        return $status;
    }

    private function getCustomerId(){
        $customerId = $this->customerSession->getCustomer()->getGroupId();
        return $customerId;
    }

    public function getVirtualSerialCodes($serailItem,$type){
       
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/pdf-create-testtt.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);

        $string = '';
        if($type == 'bundle'){
            $string = 'B';
        }else{
            $string = 'V';
        }

        $xml = '';
        $xml .= '<items>';
        foreach ($serailItem as $key => $item){
            $data = explode(',',$item);
            $quoteId = $data['0'];
            $orderId = $data['1'];
            $sku = $data['2'];
            $qty = $data['3'];
            for($i=1;$i<=$qty;$i++) {
                $random = rand(10, 30);
                $time = time() + $key+$i+(int)$random;
                $serialcode = $string.$time;
                $xml .= '<item>
                            <QUOTEIDS>' . $quoteId . '</QUOTEIDS>
                            <OrderID>' . $orderId . '</OrderID>
                            <Item>' . $sku . '</Item>
                            <SerialNumber>' . $serialcode . '</SerialNumber>
                            <ExpireDate>0</ExpireDate>
                            <PIN>0</PIN>
                            <SecondSerialCode>0</SecondSerialCode>
                            <URL>0</URL>
                            <StartDate>0</StartDate>
                            <Value>0</Value>
                            <Error></Error>
                        </item>';
            }
        }
        $xml .= '</items>';

        $xmlResPonse = simplexml_load_string($xml);
        $serilCodes = array();

        if(!empty($xmlResPonse->item))
        {
            $AllData = array();
            $i=0;
            $count = 0;
            $message = array();
            foreach($xmlResPonse->item as $item)
            {
                $sku = trim($item->Item);
                if(!in_array($sku,$AllData))
                {
                    $i=0;
                    $AllData[] = $sku;
                }
                $error = (string)trim($item->Error);
                if($error == '') {
                    $serilCodes['response'] = "Success";
                    $serilCodes['sku'][$sku][$i]['OrderID'] = (string)trim($item->OrderID);
                    $serilCodes['sku'][$sku][$i]['SerialNumber'] = (string)trim($item->SerialNumber);
                    $serilCodes['sku'][$sku][$i]['ExpireDate'] = (string)trim($item->ExpireDate);
                    $serilCodes['sku'][$sku][$i]['PIN'] = (string)trim($item->PIN);
                    $serilCodes['sku'][$sku][$i]['SecondSerialCode'] = (string)trim($item->SecondSerialCode[0]);
                    $serilCodes['sku'][$sku][$i]['URL'] = (string)trim($item->URL[0]);
                    $serilCodes['sku'][$sku][$i]['StartDate'] = (string)trim($item->StartDate);
                    $serilCodes['sku'][$sku][$i]['Value'] = (string)trim($item->Value);
                }
                else{
                    $serilCodes['response'] = "Error";
                    $message[] = $sku.":".$error;
                }
                $i++;
            }
            $serilCodes['TotalCount'] = count($xmlResPonse);
        }
        if($serilCodes['response'] == "Error"){
            $serilCodes['message'] = implode(",", $message);
        }
        return $serilCodes;

    }

}
