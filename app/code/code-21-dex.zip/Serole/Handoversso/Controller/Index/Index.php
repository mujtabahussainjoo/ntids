<?php
/**
 * Created by Serole(Dk) on 16/11/2018.
 * For SSO integration
 */
namespace Serole\Handoversso\Controller\Index;

use Magento\Framework\App\Action\Context;

class Index extends \Magento\Framework\App\Action\Action
{
	/* logging */
	protected $_logger;
	
	
	protected $_storeManager;
	
	   /**
     * @param Context $context
     */
    public function __construct(
        Context $context,
		\Magento\Store\Model\StoreManagerInterface $storeManager

    ) 
	{
		$this->_storeManager = $storeManager;        
        parent::__construct($context);
    }
	
	/**
     * SSO integration for different store
     */
    public function execute()
    {
		$this->createLog('handoversso.log');
		
		$store_code = $this->getStoreCode();
		
        $this->_logger->info("Store code=".$store_code);
		
        
        $success = false;
		$oldHandover = false;
		$skipRedirect = false;
		$parms='';
		if ($store_code == 'rac_en' ) { 
			$success = false;	
			$oldHandover = true;
			$parms = 'website=rac&';
		} elseif ($store_code == 'hbf_en' ) { 
			//$success = $this->validateHBF();	
			
		} elseif ($store_code == 'racv' ) { 
			//$success = $this->validateRACV();	
			
		} elseif ($store_code == 'universitywa' ) { 
			//$success = $this->validateUniversityWA();	
			
			if (!$success){
				//$this->_redirectUrl('universitywa-unable-to-locate');
			}
			
			$skipRedirect = true; 		
		} elseif ($store_code == 'coles_en' ) {
			//$success = $this->validateColes();	
		} elseif ($store_code == 'acorns' ) {
			//$success = $this->validateAcorns();	
		}
		
		
		foreach($this->getRequest()->getParams() as $key=>$value){
			$parms.=$key.'='.$value.'&';
		}

		if ($skipRedirect) {
			// do nothing :)
			
		} else if ($success){
			$this->_logger->info("All Good, Going to home age");
			$this->_redirectUrl('/?'.$parms);	
					
		} else if ($oldHandover==true){
			$this->_logger->info("Reverting to old handover");
			// Send the user to the login page 
			$this->_logger->info("redirected to handover with param:".$parms);
			$this->_redirectUrl('*/handover/?'.$parms);

		}
    }
	
	
	 /**
     * Get store identifier
     *
     * @return  int
     */
    public function getStoreId()
    {
        return $this->_storeManager->getStore()->getId();
    }
    
    /**
     * Get website identifier
     *
     * @return string|int|null
     */
    public function getWebsiteId()
    {
        return $this->_storeManager->getStore()->getWebsiteId();
    }
    
    /**
     * Get Store code
     *
     * @return string
     */
    public function getStoreCode()
    {
        return $this->_storeManager->getStore()->getCode();
    }
	
	public function createLog($file)
	{
		$writer = new \Zend\Log\Writer\Stream(BP . '/var/log/'.$file);
		$this->_logger = new \Zend\Log\Logger();
		$this->_logger->addWriter($writer);
	}
}