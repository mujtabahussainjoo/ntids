<?php

namespace Serole\Serialcode\Block\Adminhtml\Codes\Edit;


class Form extends \Magento\Backend\Block\Widget\Form\Generic
{

    protected $_systemStore;


    protected $eav;


    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Cms\Model\Wysiwyg\Config $wysiwygConfig,
        \Magento\Store\Model\System\Store $systemStore,
        \Magento\Eav\Model\Config $eav,
        array $data = []
    ) {
        $this->_wysiwygConfig = $wysiwygConfig;
        $this->_systemStore = $systemStore;
        $this->eav = $eav;
        parent::__construct($context, $registry, $formFactory, $data);
    }


    protected function _prepareForm()
    {
        $dateFormat = $this->_localeDate->getDateFormat(\IntlDateFormatter::SHORT);
        $model = $this->_coreRegistry->registry('serialcode_data');
        $form = $this->_formFactory->create(
            ['data' => [
                'id' => 'edit_form',
                'enctype' => 'multipart/form-data',
                'action' => $this->getData('action'),
                'method' => 'post'
            ]
            ]
        );



        if ($model->getId()) {
            $fieldset = $form->addFieldset(
                'base_fieldset',
                ['legend' => __('Edit Row Data'), 'class' => 'fieldset-wide']
            );
            $fieldset->addField('id', 'hidden', ['name' => 'id']);
        } else {
            $fieldset = $form->addFieldset(
                'base_fieldset',
                ['legend' => __('Add Row Data'), 'class' => 'fieldset-wide']
            );
        }


       $status  = array('0' => 'released','1' => 'assigned');
       $mode = array('auto' => 'auto', 'manual' => 'manual');


        $fieldset->addField(
            'OrderID',
            'text',
            [
                'name' => 'OrderID',
                'label' => __('Order Id'),
                'title' => __('Order ID'),
                'required' => true,

            ]
        );


        $fieldset->addField(
            'sku',
            'text',
            [
                'name' => 'sku',
                'label' => __('Sku'),
                'title' => __('Sku'),
                'required' => true,
            ]
        );


        $fieldset->addField(
            'parentsku',
            'text',
            [
                'name' => 'parentsku',
                'label' => __('Parent Sku'),
                'title' => __('Parent Sku'),
            ]
        );


        $fieldset->addField(
            'SerialNumber',
            'text',
            [
                'name' => 'SerialNumber',
                'label' => __('Serial Code'),
                'title' => __('Serial Code'),
                'required' => true,
            ]
        );


        $fieldset->addField(
            'status',
            'select',
            [
                'name' => 'status',
                'label' => __('Status'),
                'title' => __('Status'),
                'required' => true,
                'values' => $status,
            ]
        );


        $fieldset->addField(
            'mode',
            'select',
            [
                'name' => 'mode',
                'label' => __('Mode'),
                'title' => __('Mode'),
                'required' => true,
                'values' => $mode,
            ]
        );

        $fieldset->addField(
            'email',
            'text',
            [
                'name' => 'email',
                'label' => __('Customer Email'),
                'title' => __('Customer Email'),
                'required' => true,
            ]
        );







        $form->setValues($model->getData());
        $form->setUseContainer(true);
        $this->setForm($form);

        return parent::_prepareForm();
    }
}
