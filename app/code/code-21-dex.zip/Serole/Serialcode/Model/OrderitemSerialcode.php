<?php

namespace Serole\Serialcode\Model;

class OrderitemSerialcode extends \Magento\Framework\Model\AbstractModel
{

    protected function _construct()
    {
        $this->_init('Serole\Serialcode\Model\ResourceModel\OrderitemSerialcode');
    }

   
}