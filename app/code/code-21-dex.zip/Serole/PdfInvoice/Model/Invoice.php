<?php

namespace Serole\PdfInvoice\Model;


class Invoice extends \Magento\Sales\Model\Order\Pdf\Invoice{
		
	    public function getPdf($invoices = []){
        $this->_beforeGetPdf();
        $this->_initRenderer('invoice');

        $pdf = new \Zend_Pdf();
        $this->_setPdf($pdf);
        $style = new \Zend_Pdf_Style();
        $this->_setFontBold($style, 10);

        foreach ($invoices as $invoice) {
            if ($invoice->getStoreId()) {
                $this->_localeResolver->emulate($invoice->getStoreId());
                $this->_storeManager->setCurrentStore($invoice->getStoreId());
            }
            $page = $this->newPage();
            $order = $invoice->getOrder();
            /* Add image */
            $this->insertLogo($page, $invoice->getStore());
            /* Add address */
            $this->insertAddress($page, $invoice->getStore());
            /* Add head */
            $this->insertOrder(
                $page,
                $order,
                $this->_scopeConfig->isSetFlag(
                    self::XML_PATH_SALES_PDF_INVOICE_PUT_ORDER_ID,
                    \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
                    $order->getStoreId()
                )
            );
            /* Add document text and number */
            $this->insertDocumentNumber($page, __('Invoice # ') . $invoice->getIncrementId());
            /* Add table */
            $this->_drawHeader($page);
            /* Add body */
            foreach ($invoice->getAllItems() as $item) {
                if ($item->getOrderItem()->getParentItem()) {
                    continue;
                }
                /* Draw item */
                $this->_drawItem($item, $page, $order);
                $page = end($pdf->pages);
            }
            /* Add totals */
            $this->insertTotals($page, $invoice);
            if ($invoice->getStoreId()) {
                $this->_localeResolver->revert();
            }
        }
		$this->_drawFooter($page);   
        $this->_afterGetPdf();
        return $pdf;
    }
	
		protected function _drawFooter(\Zend_Pdf_Page $page){
		/*varible from store config*/
		$storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_WEBSITES;
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		echo $footerMsg = $objectManager->get('Magento\Framework\App\Config\ScopeConfigInterface')->getValue("description/description/description", $storeScope);
		//exit();
		/***/
		$this->y =50;    
		$page->setFillColor(new \Zend_Pdf_Color_RGB(1, 1, 1));
		$page->setLineColor(new \Zend_Pdf_Color_GrayScale(0.5));
		$page->setLineWidth(0.5);
		//$page->drawRectangle(60, $this->y, 525, $this->y -30);

		$page->setFillColor(new \Zend_Pdf_Color_RGB(0.1, 0.1, 0.1));
		$page->setFont(\Zend_Pdf_Font::fontWithName(\Zend_Pdf_Font::FONT_HELVETICA), 10);
		$this->y -=10;
		//$page->drawText("Tax invoice issued by Neat Tickets Pty Ltd. PO Box 257, Osborne Park, WA 6917. ABN 12 153 820 887", 70, $this->y, 'UTF-8');
		$page->drawText($footerMsg, 70, $this->y, 'UTF-8');
		//$page->drawText("Company name", 70, $this->y, 'UTF-8');
		//$page->drawText("Tel: +123 456 676", 230, $this->y, 'UTF-8');
		//$page->drawText("Registered in Country name", 430, $this->y, 'UTF-8');
	}
	
}
	
	