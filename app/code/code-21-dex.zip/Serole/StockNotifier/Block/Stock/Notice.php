<?php


namespace Serole\StockNotifier\Block\Stock;

class Notice extends \Magento\Framework\View\Element\Template
{

    /**
     * Constructor
     *
     * @param \Magento\Framework\View\Element\Template\Context  $context
     * @param array $data
     */
    public function __construct(
	\Magento\Framework\View\Element\Template\Context $context,
	 \Magento\Framework\Registry $registry,
	 \Magento\CatalogInventory\Model\Stock\StockItemRepository $stockItemRepository,
	  array $data = []
	){
		$this->_stockItemRepository = $stockItemRepository; 
		$this->_registry = $registry;          	
		parent::__construct($context, $data);
    }

    /**
     * @return string
     */
    public function stockNotice()
    {
        //Your block code
		$currentProduct = $this->_registry->registry('current_product');
		$StockNotifiation = $currentProduct->getStockNotifiation();
		$StockThreshold = $currentProduct->getStockThreshold();
		// print_r ($currentProduct->getSku()) . '<br />';    
		// print_r ($currentProduct->getStockNotifiation()) . '<br />';    
		// print_r ($currentProduct->getStockThreshold()) . '<br />';   
		$productStock =$this->_stockItemRepository->get($currentProduct->getId());
		$qty=$productStock->getQty();
		//print_r ($qty) . '<br />';  
			if($StockNotifiation > 0 && $StockNotifiation!==''){ 
			 if($qty <= $StockThreshold){ 
				$msg='Limited Products ! Only '.$qty.' left';
				return __($msg);
			 }	
			}	

    }
}
